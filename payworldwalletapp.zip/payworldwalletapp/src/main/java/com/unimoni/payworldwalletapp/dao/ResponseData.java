package com.unimoni.payworldwalletapp.dao;


import com.fasterxml.jackson.databind.annotation.JsonSerialize;

import lombok.AllArgsConstructor;
import lombok.NoArgsConstructor;

@SuppressWarnings("deprecation")
@NoArgsConstructor
@AllArgsConstructor
@JsonSerialize(include = JsonSerialize.Inclusion.NON_NULL)
public class ResponseData {
	
	private boolean error;    
	private String errorMsg;
	private String msg;
   	private String Status;
   	private String TxnId;
    
	public boolean isError() {
		return error;
	}
	public void setError(boolean error) {
		this.error = error;
	}
	public String getErrorMsg() {
		return errorMsg;
	}
	public void setErrorMsg(String errorMsg) {
		this.errorMsg = errorMsg;
	}
	public String getMsg() {
		return msg;
	}
	public void setMsg(String msg) {
		this.msg = msg;
	}
	public String getStatus() {
		return Status;
	}
	public void setStatus(String status) {
		Status = status;
	}
	public String getTxnId() {
		return TxnId;
	}
	public void setTxnId(String txnId) {
		TxnId = txnId;
	}
	
	public ResponseData(boolean error, String errorMsg, String msg, String status, String txnId) {
		super();
		this.error = error;
		this.errorMsg = errorMsg;
		this.msg = msg;
		Status = status;
		TxnId = txnId;
	}
	
}
