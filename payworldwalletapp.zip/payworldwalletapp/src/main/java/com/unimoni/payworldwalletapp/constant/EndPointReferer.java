package com.unimoni.payworldwalletapp.constant;

public final class EndPointReferer {
	
     // 	ApplicationWorkFlowRelated Endpoints
	
    public static final String PAYWORLD = "/payworld";
    public static final String TRANSACTION = "/transaction/{token-id}/{party-code}";
    public static final String BALANCECHECK = "/balancecheck/{token-id}/{party-code}";
    public static final String TRANSACTIONSTATUS = "/transactionStatus/{token-id}/{party-code}";
    public static final String NOTIFICATION = "/notification/{token-id}/{party-code}";
    public static final String REFUND = "/refund/{token-id}/{party-code}";

}
