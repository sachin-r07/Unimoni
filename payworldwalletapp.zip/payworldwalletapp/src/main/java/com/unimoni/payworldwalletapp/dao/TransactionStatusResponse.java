package com.unimoni.payworldwalletapp.dao;

import com.fasterxml.jackson.databind.annotation.JsonSerialize;

import lombok.AllArgsConstructor;
import lombok.NoArgsConstructor;

@SuppressWarnings("deprecation")
@NoArgsConstructor
@AllArgsConstructor
@JsonSerialize(include = JsonSerialize.Inclusion.NON_NULL)
public class TransactionStatusResponse {
	
	private boolean error;
	private ResponseData data;
	
	
	public boolean isError() {
		return error;
	}
	public void setError(boolean error) {
		this.error = error;
	}
	public ResponseData getData() {
		return data;
	}
	public void setData(ResponseData data) {
		this.data = data;
	}	

	public TransactionStatusResponse(boolean error, ResponseData data) {
		super();
		this.error = error;
		this.data = data;
	}

}
