package com.unimoni.payworldwalletapp.configuration;


import org.springframework.context.annotation.Configuration;

import io.swagger.v3.oas.annotations.OpenAPIDefinition;
import io.swagger.v3.oas.annotations.info.Info;


@Configuration
@OpenAPIDefinition(info = @Info(title = "Payworld Wallet API", version = "v1"))
public class OpenApi30Configuration {
}

