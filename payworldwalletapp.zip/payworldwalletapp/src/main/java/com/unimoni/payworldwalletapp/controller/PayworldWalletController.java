package com.unimoni.payworldwalletapp.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.unimoni.payworldwalletapp.constant.EndPointReferer;
import com.unimoni.payworldwalletapp.dao.BalanceCheckResponse;
import com.unimoni.payworldwalletapp.dao.NotificationResponse;
import com.unimoni.payworldwalletapp.dao.RefundResponse;
import com.unimoni.payworldwalletapp.dao.TransactionResponse;
import com.unimoni.payworldwalletapp.dao.TransactionStatusResponse;
import com.unimoni.payworldwalletapp.service.PayworldService;

@RestController
@RequestMapping(value = EndPointReferer.PAYWORLD)
public class PayworldWalletController {

	@Autowired
	private PayworldService payworldService;
		
	@PostMapping(EndPointReferer.BALANCECHECK)
	public ResponseEntity<BalanceCheckResponse> balanceCheck(@PathVariable("token-id") String tokenId,@PathVariable("party-code") String partyCode,@RequestBody String balanceCheckRequest) {
		return payworldService.balanceCheck(tokenId,partyCode,balanceCheckRequest);
	}
	@PostMapping(EndPointReferer.TRANSACTION)
	public ResponseEntity<TransactionResponse> transaction(@PathVariable("token-id") String tokenId,@PathVariable("party-code") String partyCode,@RequestBody String transactionRequest) {
		return payworldService.transaction(tokenId,partyCode,transactionRequest);
	}

	@PostMapping(EndPointReferer.TRANSACTIONSTATUS)
	public ResponseEntity<TransactionStatusResponse> transactionStatus(@PathVariable("token-id") String tokenId,@PathVariable("party-code") String partyCode,@RequestBody String transactionStatusRequest) {
		return payworldService.transactionStatus(tokenId,partyCode,transactionStatusRequest);
	}	
	
	@PostMapping(EndPointReferer.NOTIFICATION)
	public ResponseEntity<NotificationResponse> notification(@PathVariable("token-id") String tokenId,@PathVariable("party-code") String partyCode,@RequestBody String notificationRequest) {
		return payworldService.notification(tokenId,partyCode,notificationRequest);
	}
	
	@PostMapping(EndPointReferer.REFUND)
	public ResponseEntity<RefundResponse> refund(@PathVariable("token-id") String tokenId,@PathVariable("party-code") String partyCode,@RequestBody String refundRequest) {
		return payworldService.refund(tokenId,partyCode,refundRequest);
	}
}
