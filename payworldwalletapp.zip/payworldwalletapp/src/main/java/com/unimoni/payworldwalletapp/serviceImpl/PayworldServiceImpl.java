package com.unimoni.payworldwalletapp.serviceImpl;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.google.gson.Gson;
import com.unimoni.payworldwalletapp.dao.BalanceCheckResponse;
import com.unimoni.payworldwalletapp.dao.NotificationResponse;
import com.unimoni.payworldwalletapp.dao.RefundResponse;
import com.unimoni.payworldwalletapp.dao.TransactionResponse;
import com.unimoni.payworldwalletapp.dao.TransactionStatusResponse;
import com.unimoni.payworldwalletapp.service.PayworldService;

@Service
public class PayworldServiceImpl implements PayworldService {

	private static final Logger logger = LoggerFactory.getLogger(PayworldServiceImpl.class);

	@Autowired
	private RestTemplate restTemplate;

	@Value("${balanceCheckUrl}")
	private String balanceCheckUrl;

	@Value("${transactionUrl}")
	private String transactionUrl;
	
	@Value("${transactionStatusUrl}")
	private String transactionStatusUrl;
	
	@Value("${notificationUrl}")
	private String notificationUrl;
	
	@Value("${refundUrl}")
	private String refundUrl;

//	@Value("${partyCode}")
//	private String partyCode;
//
//	@Value("${tokenId}")
//	private String tokenId;

	
	@Override
	public ResponseEntity<BalanceCheckResponse> balanceCheck(String tokenId, String partyCode,String balanceCheckRequest) {
		String responseBody = null;
		BalanceCheckResponse balanceCheckResponse = null;
		// Set Header Data
		HttpHeaders headers = setHeaderData(tokenId,partyCode);
		HttpEntity<String> entity = new HttpEntity<>(balanceCheckRequest, headers);
		// Call Third Party API
		try {
			responseBody = restTemplate.exchange(balanceCheckUrl, HttpMethod.POST, entity, String.class).getBody();
			balanceCheckResponse = new Gson().fromJson(responseBody, BalanceCheckResponse.class);
			return ResponseEntity.status(HttpStatus.OK).body(balanceCheckResponse);
			
		} catch (Exception e) {
			responseBody = e.getMessage().substring(e.getMessage().indexOf("{"), e.getMessage().indexOf("}") + 1);
			logger.info("BalanceCheckErrorResponse: "+responseBody);
			balanceCheckResponse = new Gson().fromJson(responseBody, BalanceCheckResponse.class);
			return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(balanceCheckResponse);
		}
	}

	@Override
	public ResponseEntity<TransactionResponse> transaction(String tokenId, String partyCode,String transactionRequest) {
		String responseBody = null;
		TransactionResponse transactionResponse = null;
		// Set Header Data
		HttpHeaders headers = setHeaderData(tokenId,partyCode);
		HttpEntity<String> entity = new HttpEntity<>(transactionRequest, headers);
		// Call Third Party API
		try {
			responseBody = restTemplate.exchange(transactionUrl, HttpMethod.POST, entity, String.class).getBody();
			transactionResponse = new Gson().fromJson(responseBody, TransactionResponse.class);
			return ResponseEntity.status(HttpStatus.OK).body(transactionResponse);

		} catch (Exception e) {
			responseBody = e.getMessage().substring(e.getMessage().indexOf("{"), e.getMessage().indexOf("}") + 2);
			logger.info("TransactionErrorResponse: "+responseBody);
			transactionResponse = new Gson().fromJson(responseBody, TransactionResponse.class);
			return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(transactionResponse);
		}
	}

	@Override
	public ResponseEntity<TransactionStatusResponse> transactionStatus(String tokenId, String partyCode,String transactionStatusRequest) {
		String responseBody = null;
		TransactionStatusResponse transactionStatusResponse = null;
		// Set Header Data
		HttpHeaders headers = setHeaderData(tokenId,partyCode);
		HttpEntity<String> entity = new HttpEntity<>(transactionStatusRequest, headers);
		// Call Third Party API
		try {
			responseBody = restTemplate.exchange(transactionStatusUrl, HttpMethod.POST, entity, String.class).getBody();
			transactionStatusResponse = new Gson().fromJson(responseBody, TransactionStatusResponse.class);
			return ResponseEntity.status(HttpStatus.OK).body(transactionStatusResponse);
		} catch (Exception e) {
			responseBody = e.getMessage().substring(e.getMessage().indexOf("{"), e.getMessage().indexOf("}") + 2);
			logger.info("TransactionStatusErrorResponse: "+responseBody);
			transactionStatusResponse = new Gson().fromJson(responseBody, TransactionStatusResponse.class);
			return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(transactionStatusResponse);

		}

	}

	@Override
	public ResponseEntity<NotificationResponse> notification(String tokenId, String partyCode,String notificationRequest) {

		String responseBody = null;
		NotificationResponse notificationResponse = null;
		// Set Header Data
		HttpHeaders headers = setHeaderData(tokenId,partyCode);
		HttpEntity<String> entity = new HttpEntity<>(notificationRequest, headers);
		// Call Third Party API
		try {
			responseBody = restTemplate.exchange(transactionStatusUrl, HttpMethod.POST, entity, String.class).getBody();
			notificationResponse = new Gson().fromJson(responseBody, NotificationResponse.class);
			return ResponseEntity.status(HttpStatus.OK).body(notificationResponse);
		} catch (Exception e) {
			responseBody = e.getMessage().substring(e.getMessage().indexOf("{"), e.getMessage().indexOf("}") + 2);
			logger.info("NotificationErrorResponse: "+responseBody);
			notificationResponse = new Gson().fromJson(responseBody, NotificationResponse.class);
			return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(notificationResponse);
		}

	}

	@Override
	public ResponseEntity<RefundResponse> refund(String tokenId, String partyCode,String refundRequest) {
		String responseBody = null;
		RefundResponse refundResponse = null;
		// Set Header Data
		HttpHeaders headers = setHeaderData(tokenId,partyCode);
		HttpEntity<String> entity = new HttpEntity<>(refundRequest, headers);
		// Call Third Party API
		try {
			responseBody = restTemplate.exchange(refundUrl, HttpMethod.POST, entity, String.class).getBody();
			refundResponse = new Gson().fromJson(responseBody, RefundResponse.class);
			return ResponseEntity.status(HttpStatus.OK).body(refundResponse);
		} catch (Exception e) {
			responseBody = e.getMessage().substring(e.getMessage().indexOf("{"), e.getMessage().indexOf("}") + 2);
			logger.info("RefundErrorResponse: "+responseBody);
			refundResponse = new Gson().fromJson(responseBody, RefundResponse.class);
			return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(refundResponse);

		}

	}
	
	private HttpHeaders setHeaderData(String tokenId, String partyCode) {
		HttpHeaders headers = new HttpHeaders();
		headers.setContentType(MediaType.APPLICATION_JSON);
		headers.set("X-ACCESS-TOKEN", tokenId);
		headers.set("PARTY-CODE", partyCode);
		return headers;
	}
}
