package com.unimoni.payworldwalletapp.service;

import org.springframework.http.ResponseEntity;

import com.unimoni.payworldwalletapp.dao.BalanceCheckResponse;
import com.unimoni.payworldwalletapp.dao.NotificationResponse;
import com.unimoni.payworldwalletapp.dao.RefundResponse;
import com.unimoni.payworldwalletapp.dao.TransactionResponse;
import com.unimoni.payworldwalletapp.dao.TransactionStatusResponse;

public interface PayworldService {

	ResponseEntity<BalanceCheckResponse> balanceCheck(String tokenId, String partyCode,String balanceCheckRequest);

	ResponseEntity<TransactionResponse> transaction(String tokenId,String partyCode,String transactionRequest);

	ResponseEntity<TransactionStatusResponse> transactionStatus(String tokenId, String partyCode,String transactionStatusRequest);

	ResponseEntity<NotificationResponse> notification(String tokenId, String partyCode,String notificationRequest);

	ResponseEntity<RefundResponse> refund(String tokenId, String partyCode,String refundRequest);

}
