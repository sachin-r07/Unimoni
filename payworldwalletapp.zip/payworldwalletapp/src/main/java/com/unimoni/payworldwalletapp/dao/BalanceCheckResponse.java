package com.unimoni.payworldwalletapp.dao;

import com.fasterxml.jackson.databind.annotation.JsonSerialize;

import lombok.AllArgsConstructor;
import lombok.NoArgsConstructor;
@SuppressWarnings("deprecation")
@NoArgsConstructor
@AllArgsConstructor
@JsonSerialize(include = JsonSerialize.Inclusion.NON_NULL)
public class BalanceCheckResponse {
	
	private boolean error;
	private String errorMsg;
	private ResponseData data;
	
	public String getErrorMsg() {
		return errorMsg;
	}
	public void setErrorMsg(String errorMsg) {
		this.errorMsg = errorMsg;
	}
	public boolean isError() {
		return error;
	}
	public void setError(boolean error) {
		this.error = error;
	}
	public ResponseData getData() {
		return data;
	}
	
	public BalanceCheckResponse(boolean error, String errorMsg, ResponseData data) {
		super();
		this.error = error;
		this.errorMsg = errorMsg;
		this.data = data;
	}
	public void setData(ResponseData data) {
		this.data = data;
	}		
}
