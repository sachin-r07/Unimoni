package com.unimoni.phonepeapp.enumconstants;

public enum RedirectMode {
	
	GET, POST
}
