package com.unimoni.phonepeapp.exception;
@SuppressWarnings("serial")
public class ExceptionAfter30Second extends RuntimeException{
	
public ExceptionAfter30Second (String message){
        
		super(message);
    }
}
