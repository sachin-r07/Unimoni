package com.unimoni.phonepeapp.serviceImpl;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.Base64;
import java.util.Map;
import java.util.Random;

import javax.json.Json;
import javax.json.JsonObject;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.unimoni.phonepeapp.dao.CallbackRequest;
import com.unimoni.phonepeapp.dao.PayApiRequest;
import com.unimoni.phonepeapp.dao.PayApiResponse;
import com.unimoni.phonepeapp.dao.PaymentData;
import com.unimoni.phonepeapp.dao.PaymentInstrument;
import com.unimoni.phonepeapp.dao.TransactionResponse;
import com.unimoni.phonepeapp.enumconstants.RedirectMode;
import com.unimoni.phonepeapp.enumconstants.Type;
import com.unimoni.phonepeapp.service.PhonepeService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

@Service
public class PhonepeServiceImpl implements PhonepeService {

	private static final Logger logger = LoggerFactory.getLogger(PhonepeServiceImpl.class);

	@Autowired
	private RestTemplate restTemplate;

	@Autowired
	private RetryableService retryableService;

	@Value("${redirectUrl}")
	private String redirectUrl;

	@Value("${callbackUrl}")
	private String callbackUrl;

	@Value("${payApiurl}")
	private String payApiurl;

	@Value("${checkStatusUrl}")
	private String checkStatusUrl;

	@Value("${stringUrl}")
	private String stringUrl;

	@Value("${endpointURL}")
	private String endpointURL;
	
	String saltKey =null;

	public PayApiResponse initiatePayment(PayApiRequest payApiRequest) {
		// build pay-API request
		buildPayApiRequest(payApiRequest);
		String merchantTransactionId = payApiRequest.getMerchantTransactionId();
		String encode = encodeBase64(payApiRequest);
		String encodedHeaderPayload = encode + endpointURL + payApiRequest.getSaltKey();
		String SHA256 = null;
		try {
			SHA256 = convertToSHA256(encodedHeaderPayload);
		} catch (NoSuchAlgorithmException e) {
			e.printStackTrace();
		}

		HttpHeaders headers = new HttpHeaders();
		headers.setContentType(MediaType.APPLICATION_JSON);
		headers.set("X-VERIFY", SHA256 + "###1");
		JsonObject jsonRequest = Json.createObjectBuilder().add("request", encode).build();
		String request = jsonRequest.toString();
		HttpEntity<String> entity = new HttpEntity<>(request, headers);
		String responseBody = null;
		String urlFromResponse = null;
		PayApiResponse payApiResponse = null;
		ObjectMapper mapper = new ObjectMapper();
		// call to Phonepe API
		try {
			responseBody = restTemplate.exchange(payApiurl, HttpMethod.POST, entity, String.class).getBody();
			if (responseBody != null) {
				payApiResponse = mapper.readValue(responseBody, PayApiResponse.class);
				logger.info("payApiResponse: "+responseBody.toString());
				Map<String, Object> data = payApiResponse.getData();
				logger.info("payApiResponse: "+data.toString());

				Map<String, Object> instrumentObject = (Map<String, Object>) data.get("instrumentResponse");
				if (instrumentObject != null) {
					Map<String, Object> redirectObject = (Map<String, Object>) instrumentObject.get("redirectInfo");
					urlFromResponse = (String) redirectObject.get("url");
					logger.info("merchantTransactionId: " + merchantTransactionId);
				}
			}
		} catch (Exception e) {
			e.getStackTrace();
		}
		return payApiResponse;
	}

	@Override
	public TransactionResponse callBack(CallbackRequest base64Payload) {
		TransactionResponse transactionResponse = new TransactionResponse();
		ObjectMapper mapper = new ObjectMapper();
		try {
			String decodedPayload = new String(Base64.getDecoder().decode(base64Payload.getRequest()));
			transactionResponse = mapper.readValue(decodedPayload, TransactionResponse.class);
		} catch (JsonProcessingException e) {
			throw new RuntimeException(e);
		}
		upiAmountConvert(transactionResponse);

		String merchantTransactionId = transactionResponse.getData().getMerchantTransactionId();
		String merchantId = transactionResponse.getData().getMerchantId();
		//String saltKey= transactionResponse.getData().get

		if (true == (transactionResponse.isSuccess())) {
			return transactionResponse;

		} else if (transactionResponse.getCode().equals("PAYMENT_PENDING")) {
			TransactionResponse checkStatusResponse = checkStatus(merchantId, merchantTransactionId,saltKey);
			return checkStatusResponse;
		}
		return transactionResponse;
	}
	
	public TransactionResponse checkStatus(String merchantId, String merchantTransactionId, String saltKey) {
		final String url = checkStatusUrl + merchantId + "/" + merchantTransactionId;
		String plainString = stringUrl + merchantId + "/" + merchantTransactionId + saltKey;
		String SHA256 = null;
		try {
			SHA256 = convertStringToSha256(plainString);
		} catch (NoSuchAlgorithmException e) {
			e.printStackTrace();
		}
		// setting Request Headers
		HttpHeaders headers = new HttpHeaders();
		headers.setContentType(MediaType.APPLICATION_JSON);
		headers.set("X-MERCHANT-ID", merchantId);
		headers.set("X-VERIFY", SHA256 + "###1");
		HttpEntity<String> entity = new HttpEntity<>(null, headers);

		// calls checkStatus API
		try {
			Thread.sleep(25000);
			TransactionResponse transactionResponse = retryableService.checkStatusAfter25Second(url, entity);
			return transactionResponse;
		} catch (Exception e1) {
			try {
				Thread.sleep(3000);
				TransactionResponse transactionResponse = retryableService.checkStatusAfter3Second(url, entity);
				return transactionResponse;
			} catch (Exception e) {
				try {
					Thread.sleep(6000);
					TransactionResponse transactionResponse = retryableService.checkStatusAfter6Second(url, entity);
					return transactionResponse;
				} catch (Exception e2) {
					try {
						Thread.sleep(10000);
						TransactionResponse transactionResponse = retryableService.checkStatusAfter10Second(url,entity);
						return transactionResponse;
					} catch (Exception e3) {
						try {
							Thread.sleep(30000);
							TransactionResponse transactionResponse = retryableService.checkStatusAfter30Second(url,entity);
							return transactionResponse;
						} catch (Exception e4) {
							try {
								Thread.sleep(60000);
								TransactionResponse transactionResponse = retryableService.checkStatusAfter1minutes(url,entity);
								return transactionResponse;
							} catch (Exception e5) {
								e5.getStackTrace();
							}
						}
					}
				}
			}

		}
		return null;
	}

	private void buildPayApiRequest(PayApiRequest payApiRequest) {
	//	payApiRequest.setMerchantId(merchantId);
	//	payApiRequest.setMerchantUserId(merchantUserId);
		payApiRequest.setRedirectUrl(redirectUrl);
		payApiRequest.setCallbackUrl(callbackUrl);
		payApiRequest.setRedirectMode(RedirectMode.POST);
	//	payApiRequest.setMerchantTransactionId(generateRandomUUID());
		PaymentInstrument paymentInstrument = new PaymentInstrument();
		paymentInstrument.setType(Type.PAY_PAGE);
		payApiRequest.setPaymentInstrument(paymentInstrument);
		String merchantTransactionId = payApiRequest.setMerchantTransactionId(generateRandomUUID());
		long amount = payApiRequest.getAmount();
		long ConvertedAmount = amount * 100;
		if (ConvertedAmount >= 1) {
			payApiRequest.setAmount(ConvertedAmount);
		} else {
			logger.info("Access denied - Your amount is less than 1");
		}
	}

	private void upiAmountConvert(TransactionResponse transactionResponse) {
		PaymentData data = new PaymentData();
		double amount = transactionResponse.getData().getAmount();
		Type type = transactionResponse.getData().getPaymentInstrument().getType();
		logger.info("Type: " + type);
		String upi = "UPI";
		if (type.toString() == upi) {
			double upiAmount = amount / 100;
			logger.info("upiAmount: " + upiAmount);
			data.setAmount(upiAmount);
			transactionResponse.getData().setAmount(upiAmount);
		} else {
			data.setAmount(transactionResponse.getData().getAmount());
		}
	}

	

	public String convertToSHA256(String input) throws NoSuchAlgorithmException {
		MessageDigest digest = MessageDigest.getInstance("SHA-256");
		byte[] hash = digest.digest(input.getBytes());

		StringBuilder hexString = new StringBuilder();
		for (byte b : hash) {
			String hex = Integer.toHexString(0xff & b);
			if (hex.length() == 1) {
				hexString.append('0');
			}
			hexString.append(hex);
		}
		return hexString.toString();
	}

	public String generateRandomUUID() {

		// Generate 10 random digits
		Random random = new Random();
		int randomNumber = random.nextInt(1000000000);
		// Concatenate the UUIMONI and the random digits
		String result = "UNIMONI" + String.format("%010d", randomNumber);
		return result;
	}

	public String encodeBase64(PayApiRequest payApiRequest) {
		ObjectMapper objectMapper = new ObjectMapper();
		String jsonString = "";

		try {
			jsonString = objectMapper.writeValueAsString(payApiRequest);

		} catch (JsonProcessingException e) {
			e.printStackTrace();
		}

		byte[] jsonBytes = jsonString.getBytes();

		String base64String = Base64.getEncoder().encodeToString(jsonBytes);
		return base64String;
	}

	public String convertJsonToSha256(String encodedJson) throws NoSuchAlgorithmException {

		byte[] jsonBytes = Base64.getDecoder().decode(encodedJson);

		// Compute the SHA-256 hash of the byte array
		MessageDigest digest = MessageDigest.getInstance("SHA-256");
		byte[] hashBytes = digest.digest(jsonBytes);

		StringBuilder sb = new StringBuilder();
		for (byte b : hashBytes) {
			sb.append(String.format("%02x", b));
		}
		return sb.toString();
	}

	public String convertStringToSha256(String plainString) throws NoSuchAlgorithmException {

		byte[] jsonBytes = plainString.getBytes();

		// Compute the SHA-256 hash of the byte array
		MessageDigest digest = MessageDigest.getInstance("SHA-256");
		byte[] hashBytes = digest.digest(jsonBytes);

		StringBuilder sb = new StringBuilder();
		for (byte b : hashBytes) {
			sb.append(String.format("%02x", b));
		}
		return sb.toString();
	}
}
