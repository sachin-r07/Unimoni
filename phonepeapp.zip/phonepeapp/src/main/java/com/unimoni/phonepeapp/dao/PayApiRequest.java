package com.unimoni.phonepeapp.dao;

import com.unimoni.phonepeapp.enumconstants.RedirectMode;


public class PayApiRequest {
	
	
	private String merchantId;
	private String merchantTransactionId;
	private String merchantUserId;
	private long amount;
	private String redirectUrl;
	private RedirectMode redirectMode;
	private String callbackUrl;
	private String mobileNumber;
	private String saltKey;
	private PaymentInstrument paymentInstrument;
	
	public String getSaltKey() {
		return saltKey;
	}
	public void setSaltKey(String saltKey) {
		this.saltKey = saltKey;
	}
	public String getMerchantId() {
		return merchantId;
	}
	public void setMerchantId(String merchantId) {
		this.merchantId = merchantId;
	}
	public String getMerchantTransactionId() {
		return merchantTransactionId;
	}
	public String setMerchantTransactionId(String merchantTransactionId) {
		return this.merchantTransactionId = merchantTransactionId;
	}
	public String getMerchantUserId() {
		return merchantUserId;
	}
	public void setMerchantUserId(String merchantUserId) {
		this.merchantUserId = merchantUserId;
	}
	public long getAmount() {
		return amount;
	}
	public void setAmount(long amount) {
		this.amount = amount;
	}
	public String getRedirectUrl() {
		return redirectUrl;
	}
	public void setRedirectUrl(String redirectUrl) {
		this.redirectUrl = redirectUrl;
	}
	public RedirectMode getRedirectMode() {
		return redirectMode;
	}
	public void setRedirectMode(RedirectMode redirectMode) {
		this.redirectMode = redirectMode;
	}
	public String getCallbackUrl() {
		return callbackUrl;
	}
	public void setCallbackUrl(String callbackUrl) {
		this.callbackUrl = callbackUrl;
	}
	public String getMobileNumber() {
		return mobileNumber;
	}
	public void setMobileNumber(String mobileNumber) {
		this.mobileNumber = mobileNumber;
	}
	public PaymentInstrument getPaymentInstrument() {
		return paymentInstrument;
	}
	public void setPaymentInstrument(PaymentInstrument paymentInstrument) {
		this.paymentInstrument = paymentInstrument;
	}
	
	

}
