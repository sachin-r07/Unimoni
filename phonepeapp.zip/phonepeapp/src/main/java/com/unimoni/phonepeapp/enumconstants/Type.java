package com.unimoni.phonepeapp.enumconstants;

public enum Type {
	
	PAY_PAGE,UPI,CARD,NETBANKING

}
