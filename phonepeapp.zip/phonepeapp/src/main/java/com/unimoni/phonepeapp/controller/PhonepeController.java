package com.unimoni.phonepeapp.controller;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.unimoni.phonepeapp.dao.CallbackRequest;
import com.unimoni.phonepeapp.dao.PayApiRequest;
import com.unimoni.phonepeapp.dao.PayApiResponse;
import com.unimoni.phonepeapp.dao.TransactionResponse;
import com.unimoni.phonepeapp.service.PhonepeService;

@Controller
public class PhonepeController {

	@Autowired
	private PhonepeService phonepeService;

	@RequestMapping("/")
	public String home() {
		return "index";
	}

	@GetMapping("/create/payment")
	public String showForm(Model model) {
		PayApiRequest payApiRequest = new PayApiRequest();
		model.addAttribute("payApiRequest", payApiRequest);
		return "createPay";
	}
	@ResponseBody
	@PostMapping("/create/payment")
	public PayApiResponse initiatePayment(@ModelAttribute("phonePayRequestDto") PayApiRequest payApiRequest, Model model) {
		return phonepeService.initiatePayment(payApiRequest);
	}

	@PostMapping("/callBack")
	@ResponseBody
	public TransactionResponse callBack(@RequestBody CallbackRequest base64Payload) {
		TransactionResponse callbackJson = phonepeService.callBack(base64Payload);
		return callbackJson;
	}
	
	@GetMapping("/check-status/{merchantId}/{merchantTransactionId}/{saltKey}")
	@ResponseBody
	public TransactionResponse checkStatus(@PathVariable("merchantId") String  merchantId,
			@PathVariable("merchantTransactionId") String merchantTransactionId,@PathVariable("saltKey") String saltKey) {
		TransactionResponse transactionResponse = phonepeService.checkStatus(merchantId,merchantTransactionId,saltKey);
			return transactionResponse;
	}
}