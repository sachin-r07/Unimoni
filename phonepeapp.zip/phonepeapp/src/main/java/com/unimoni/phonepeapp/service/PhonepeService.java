package com.unimoni.phonepeapp.service;


import com.unimoni.phonepeapp.dao.CallbackRequest;
import com.unimoni.phonepeapp.dao.PayApiRequest;
import com.unimoni.phonepeapp.dao.PayApiResponse;
import com.unimoni.phonepeapp.dao.TransactionResponse;

public interface PhonepeService {
	
	
	public PayApiResponse initiatePayment( PayApiRequest PayApiRequest);
	
    public TransactionResponse callBack(CallbackRequest base64Payload);

	public TransactionResponse checkStatus(String merchantId, String merchantTransactionId, String saltKey);

}
