package com.unimoni.phonepeapp.dao;

import javax.persistence.Embeddable;
import javax.persistence.Embedded;

import com.fasterxml.jackson.databind.annotation.JsonSerialize;

import lombok.AllArgsConstructor;
import lombok.NoArgsConstructor;

@NoArgsConstructor
@AllArgsConstructor
@Embeddable
@SuppressWarnings("deprecation")
@JsonSerialize(include = JsonSerialize.Inclusion.NON_NULL)
public class Data {
	
	private String transactionId;
	private long amount; 
	private String paymentState;
	private String payResponseCode;
	private String responseCode;
	private String merchantTransactionId;
	private String merchantId;
    private String state;

	@Embedded
	private PaymentInstrument paymentInstrument;
	
	public String getState() {
		return state;
	}
	public void setState(String state) {
		this.state = state;
	}
	public String getMerchantId() {
		return merchantId;
	}
	public String setMerchantId(String merchantId) {
		return this.merchantId = merchantId;
	}
	public String getMerchantTransactionId() {
		return merchantTransactionId;
	}
	public String setMerchantTransactionId(String merchantTransactionId) {
		return this.merchantTransactionId = merchantTransactionId;
	}
	public String getResponseCode() {
		return responseCode;
	}
	public void setResponseCode(String responseCode) {
		this.responseCode = responseCode;
	}
	public String getTransactionId() {
		return transactionId;
	}
	public void setTransactionId(String transactionId) {
		this.transactionId = transactionId;
	}
	public long getAmount() {
		return amount;
	}
	public double setAmount(long amount) {
		return this.amount = amount;
	}
	public String getPaymentState() {
		return paymentState;
	}
	public void setPaymentState(String paymentState) {
		this.paymentState = paymentState;
	}
	public String getPayResponseCode() {
		return payResponseCode;
	}
	public void setPayResponseCode(String payResponseCode) {
		this.payResponseCode = payResponseCode;
	}
	public PaymentInstrument getPaymentInstrument() {
		return paymentInstrument;
	}
	public void setPaymentInstrument(PaymentInstrument paymentInstrument) {
		this.paymentInstrument = paymentInstrument;
	}
	
	

}
