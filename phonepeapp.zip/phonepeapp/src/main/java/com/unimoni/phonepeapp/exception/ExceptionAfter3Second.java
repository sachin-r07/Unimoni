package com.unimoni.phonepeapp.exception;
@SuppressWarnings("serial")
public class ExceptionAfter3Second extends RuntimeException{
	
public ExceptionAfter3Second (String message){
        
		super(message);
    }

}
