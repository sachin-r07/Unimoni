package com.unimoni.phonepeapp.dao;

import javax.persistence.Embeddable;

import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.unimoni.phonepeapp.enumconstants.Type;

import lombok.AllArgsConstructor;
import lombok.NoArgsConstructor;
@NoArgsConstructor
@AllArgsConstructor
@Embeddable
@SuppressWarnings("deprecation")
@JsonSerialize(include = JsonSerialize.Inclusion.NON_NULL)
public class PaymentInstrument {
	
	private Type type;
//	private String type;
	private String utr;
	private String bankTransactionId;
	private String arn;
	private String bankId;
	private String pgTransactionId;
	private String cardType;
	private String pgAuthorizationCode;
	private String pgServiceTransactionId;
	private String vpa;
	private String maskedAccountNumber;
	private String ifsc;
	private String upiTransactionId;
	private String unmaskedAccountNumber;
	
	public String getUnmaskedAccountNumber() {
		return unmaskedAccountNumber;
	}
	public void setUnmaskedAccountNumber(String unmaskedAccountNumber) {
		this.unmaskedAccountNumber = unmaskedAccountNumber;
	}
	public Type getType() {
		return type;
	}
	public Type setType(Type type) {
		return this.type = type;
	}
	public String getUtr() {
		return utr;
	}
	public void setUtr(String utr) {
		this.utr = utr;
	}
	public String getBankTransactionId() {
		return bankTransactionId;
	}
	public void setBankTransactionId(String bankTransactionId) {
		this.bankTransactionId = bankTransactionId;
	}
	public String getArn() {
		return arn;
	}
	public void setArn(String arn) {
		this.arn = arn;
	}
	public String getBankId() {
		return bankId;
	}
	public void setBankId(String bankId) {
		this.bankId = bankId;
	}
	public String getPgTransactionId() {
		return pgTransactionId;
	}
	public void setPgTransactionId(String pgTransactionId) {
		this.pgTransactionId = pgTransactionId;
	}
	public String getCardType() {
		return cardType;
	}
	public void setCardType(String cardType) {
		this.cardType = cardType;
	}
	public String getPgAuthorizationCode() {
		return pgAuthorizationCode;
	}
	public void setPgAuthorizationCode(String pgAuthorizationCode) {
		this.pgAuthorizationCode = pgAuthorizationCode;
	}
	public String getPgServiceTransactionId() {
		return pgServiceTransactionId;
	}
	public void setPgServiceTransactionId(String pgServiceTransactionId) {
		this.pgServiceTransactionId = pgServiceTransactionId;
	}
	public String getVpa() {
		return vpa;
	}
	public void setVpa(String vpa) {
		this.vpa = vpa;
	}
	public String getMaskedAccountNumber() {
		return maskedAccountNumber;
	}
	public void setMaskedAccountNumber(String maskedAccountNumber) {
		this.maskedAccountNumber = maskedAccountNumber;
	}
	public String getIfsc() {
		return ifsc;
	}
	public void setIfsc(String ifsc) {
		this.ifsc = ifsc;
	}
	public String getUpiTransactionId() {
		return upiTransactionId;
	}
	public void setUpiTransactionId(String upiTransactionId) {
		this.upiTransactionId = upiTransactionId;
	}
	
	


}
