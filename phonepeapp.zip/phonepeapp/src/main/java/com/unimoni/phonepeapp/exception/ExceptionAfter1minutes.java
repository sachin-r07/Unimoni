package com.unimoni.phonepeapp.exception;
@SuppressWarnings("serial")
public class ExceptionAfter1minutes extends RuntimeException{
	
public ExceptionAfter1minutes (String message){
        
		super(message);
    }
}
