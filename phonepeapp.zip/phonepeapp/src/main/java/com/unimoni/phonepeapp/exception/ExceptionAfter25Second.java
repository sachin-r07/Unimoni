package com.unimoni.phonepeapp.exception;
@SuppressWarnings("serial")
public class ExceptionAfter25Second extends RuntimeException{
	
public ExceptionAfter25Second (String message){
        
		super(message);
    }
}
