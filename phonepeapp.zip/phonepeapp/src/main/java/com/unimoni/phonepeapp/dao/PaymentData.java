package com.unimoni.phonepeapp.dao;


public class PaymentData {
	
	private String merchantId;
    private String merchantTransactionId;
    private String transactionId;
    private double amount;
    private String paymentState;
    private String payResponseCode;
    private String state;
    private String responseCode;
    private PaymentInstrument paymentInstrument;
    
	public String getMerchantId() {
		return merchantId;
	}
	public void setMerchantId(String merchantId) {
		this.merchantId = merchantId;
	}
	public String getMerchantTransactionId() {
		return merchantTransactionId;
	}
	public void setMerchantTransactionId(String merchantTransactionId) {
		this.merchantTransactionId = merchantTransactionId;
	}
	public String getTransactionId() {
		return transactionId;
	}
	public void setTransactionId(String transactionId) {
		this.transactionId = transactionId;
	}
	public double getAmount() {
		return amount;
	}
	public void setAmount(double amount) {
		this.amount = amount;
	}
	public String getPaymentState() {
		return paymentState;
	}
	public void setPaymentState(String paymentState) {
		this.paymentState = paymentState;
	}
	public String getPayResponseCode() {
		return payResponseCode;
	}
	public void setPayResponseCode(String payResponseCode) {
		this.payResponseCode = payResponseCode;
	}
	public String getState() {
		return state;
	}
	public void setState(String state) {
		this.state = state;
	}
	public String getResponseCode() {
		return responseCode;
	}
	public void setResponseCode(String responseCode) {
		this.responseCode = responseCode;
	}
	public PaymentInstrument getPaymentInstrument() {
		return paymentInstrument;
	}
	public void setPaymentInstrument(PaymentInstrument paymentInstrument) {
		this.paymentInstrument = paymentInstrument;
	}
    
    

}
