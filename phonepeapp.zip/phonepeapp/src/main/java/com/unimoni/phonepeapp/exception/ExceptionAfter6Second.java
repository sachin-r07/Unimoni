package com.unimoni.phonepeapp.exception;
@SuppressWarnings("serial")
public class ExceptionAfter6Second extends RuntimeException{
	
public ExceptionAfter6Second (String message){
        
		super(message);
    }
}
