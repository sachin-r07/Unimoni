package com.unimoni.phonepeapp.serviceImpl;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpMethod;
import org.springframework.retry.annotation.Backoff;
import org.springframework.retry.annotation.Retryable;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.unimoni.phonepeapp.dao.PaymentData;
import com.unimoni.phonepeapp.dao.TransactionResponse;
import com.unimoni.phonepeapp.exception.ExceptionAfter10Second;
import com.unimoni.phonepeapp.exception.ExceptionAfter1minutes;
import com.unimoni.phonepeapp.exception.ExceptionAfter25Second;
import com.unimoni.phonepeapp.exception.ExceptionAfter30Second;
import com.unimoni.phonepeapp.exception.ExceptionAfter3Second;
import com.unimoni.phonepeapp.exception.ExceptionAfter6Second;

@Service
public class RetryableService {

	@Autowired
	private RestTemplate restTemplate;

	private static final Logger logger = LoggerFactory.getLogger(PhonepeServiceImpl.class);

	int count = 0;

	@Retryable(value = ExceptionAfter25Second.class, maxAttempts = 1, backoff = @Backoff(delay = 25000, multiplier = 1))
	public TransactionResponse checkStatusAfter25Second(String url, HttpEntity<String> entity) throws Exception {
		TransactionResponse phonepeTransaction = null;
		phonepeTransaction = responseUtil(url, entity);
		count = 0;
		count++;
		logger.info("Count: " + count);
		if (phonepeTransaction.getCode().equals("PAYMENT_SUCCESS")) {
			logger.info("Loop Retryable Success 1: ");
			return phonepeTransaction;
		} else {
			logger.info("Retryable call After3Second 10 attempts");
			throw new ExceptionAfter3Second("Retryable call After3Second");

		}
	}

	@Retryable(value = ExceptionAfter3Second.class, maxAttempts = 10, backoff = @Backoff(delay = 3000, multiplier = 1))
	public TransactionResponse checkStatusAfter3Second(String url, HttpEntity<String> entity) throws Exception {
		TransactionResponse phonepeTransaction = null;
		phonepeTransaction = responseUtil(url, entity);
		count++;
		logger.info("Count: " + count);
		if (phonepeTransaction.getCode().equals("PAYMENT_SUCCESS")) {
			logger.info("Loop Retryable Success 2: ");
			return phonepeTransaction;
		} else if (count == 11) {
			logger.info("Retryable call After6Second 10 attempts");
			throw new ExceptionAfter6Second("Retryable call After6Second");

		} else {
			throw new ExceptionAfter3Second("Retryable call After3Second");
		}
	}

	@Retryable(value = ExceptionAfter6Second.class, maxAttempts = 10, backoff = @Backoff(delay = 6000, multiplier = 1))
	public TransactionResponse checkStatusAfter6Second(String url, HttpEntity<String> entity) throws Exception {
		TransactionResponse phonepeTransaction = null;
		phonepeTransaction = responseUtil(url, entity);
		count++;
		logger.info("Count: " + count);
		if (phonepeTransaction.getCode().equals("PAYMENT_SUCCESS")) {
			logger.info("Loop Retryable Success 3: ");
			return phonepeTransaction;
		} else if (count == 21) {
			logger.info("Retryable call After10Second 6 attempts");
			throw new ExceptionAfter10Second("Retryable call After10Second");

		} else {
			throw new ExceptionAfter6Second("Retryable call After6Second");
		}
	}

	@Retryable(value = ExceptionAfter10Second.class, maxAttempts = 6, backoff = @Backoff(delay = 10000, multiplier = 1))
	public TransactionResponse checkStatusAfter10Second(String url, HttpEntity<String> entity) throws Exception {
		TransactionResponse phonepeTransaction = null;
		phonepeTransaction = responseUtil(url, entity);
		count++;
		logger.info("Count: " + count);
		if (phonepeTransaction.getCode().equals("PAYMENT_SUCCESS")) {
			logger.info("Loop Retryable Success 4: ");
			return phonepeTransaction;
		} else if (count == 27) {
			logger.info("Retryable call After30Second 2 attempts");
			throw new ExceptionAfter30Second("Retryable call After30Second");

		} else {
			throw new ExceptionAfter10Second("Retryable call After10Second");
		}
	}

	@Retryable(value = ExceptionAfter30Second.class, maxAttempts = 2, backoff = @Backoff(delay = 30000, multiplier = 1))
	public TransactionResponse checkStatusAfter30Second(String url, HttpEntity<String> entity) throws Exception {
		TransactionResponse phonepeTransaction = null;
		phonepeTransaction = responseUtil(url, entity);
		count++;
		logger.info("Count: " + count);
		if (phonepeTransaction.getCode().equals("PAYMENT_SUCCESS")) {
			logger.info("Loop Retryable Success 5: ");
			return phonepeTransaction;
		} else if (count == 29) {
			logger.info("Retryable call After1minutes 15 attempts");
			throw new ExceptionAfter1minutes("Retryable call After1minutes");
		} else {
			throw new ExceptionAfter30Second("Retryable call After30Second");
		}
	}

	@Retryable(value = ExceptionAfter1minutes.class, maxAttempts = 15, backoff = @Backoff(delay = 60000, multiplier = 1))
	public TransactionResponse checkStatusAfter1minutes(String url, HttpEntity<String> entity) throws Exception {
		TransactionResponse phonepeTransaction = null;
		phonepeTransaction = responseUtil(url, entity);
		count++;
		logger.info("Count: " + count);
		if (phonepeTransaction.getCode().equals("PAYMENT_SUCCESS")) {
			logger.info("Loop Retryable Success 6: ");
			return phonepeTransaction;
		} else if (count == 44) {
			logger.info("Retryable call After1minutes 15 attempts Complited");
			return phonepeTransaction;
		} else {
			throw new ExceptionAfter1minutes("Retryable call After1minutes");
		}
	}

	public TransactionResponse responseUtil(String url, HttpEntity<String> entity) {
		String responseBody = null;
		TransactionResponse transactionResponse = null;
		ObjectMapper mapper = new ObjectMapper();

        // Call Third Party API
		try {
			responseBody = restTemplate.exchange(url, HttpMethod.GET, entity, String.class).getBody();
			transactionResponse = mapper.readValue(responseBody, TransactionResponse.class);
			PaymentData data = new PaymentData();
			double amount = transactionResponse.getData().getAmount();
			double upiAmount = amount / 100;
			data.setAmount(upiAmount);
			transactionResponse.getData().setAmount(upiAmount);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return transactionResponse;
	}
}
