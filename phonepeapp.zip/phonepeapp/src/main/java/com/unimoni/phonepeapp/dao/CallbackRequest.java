package com.unimoni.phonepeapp.dao;

public class CallbackRequest {
	
	private String request;
	

	public String getRequest() {
		return request;
	}

	public void setRequest(String request) {
		this.request = request;
	}


}
