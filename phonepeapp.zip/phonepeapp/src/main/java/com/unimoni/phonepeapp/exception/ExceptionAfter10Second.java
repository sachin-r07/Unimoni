package com.unimoni.phonepeapp.exception;
@SuppressWarnings("serial")
public class ExceptionAfter10Second extends RuntimeException{
	
public ExceptionAfter10Second (String message){
        
		super(message);
    }
}
