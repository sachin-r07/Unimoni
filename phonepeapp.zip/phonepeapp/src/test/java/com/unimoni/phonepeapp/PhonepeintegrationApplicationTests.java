package com.unimoni.phonepeapp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PhonepeintegrationApplicationTests {

	@Test
	void contextLoads() {
	}

}
